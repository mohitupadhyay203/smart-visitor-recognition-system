from flask import Flask, request, render_template, redirect, session, flash, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message
import os
import random
from flask_migrate import Migrate
import smtplib
from email_validator import validate_email, EmailNotValidError
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///yourdatabase.db'
db = SQLAlchemy(app)
app.secret_key = 'secret_key'





# Email credentials
EMAIL_ADDRESS = "mohitupadhyay203@gmail.com"
EMAIL_PASSWORD = "kcyulkwfkpbajtfv"  # Ensure this is the correct App Password

# Flask Mail Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = EMAIL_ADDRESS
app.config['MAIL_PASSWORD'] = EMAIL_PASSWORD

bcrypt = Bcrypt(app)
mail = Mail(app)
migrate = Migrate(app, db)

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'static/uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    profile_picture = db.Column(db.String(255), nullable=True)
    is_verified = db.Column(db.Boolean, default=False)

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password, password)

with app.app_context():
    db.create_all()

def generate_otp():
    return str(random.randint(100000, 999999))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        phone = request.form.get('phone')
        profile_picture = request.files.get('profile_picture')

        # Check if email or phone already exists in the database
        existing_user = User.query.filter((User.email == email) | (User.phone == phone)).first()
        if existing_user:
            flash("Error: Email or phone number already exists. Please use a different one.", "danger")
            return redirect(url_for('register'))

        # Handle profile picture upload
        profile_picture_filename = None
        if profile_picture and profile_picture.filename:
            upload_folder = 'static/uploads/'
            os.makedirs(upload_folder, exist_ok=True)
            filename = secure_filename(profile_picture.filename)
            profile_picture_filename = os.path.join(upload_folder, filename)
            profile_picture.save(profile_picture_filename)

        try:
            # Validate email
            valid_email = validate_email(email).email

            # Generate OTP
            otp = generate_otp()
            session['otp'] = otp
            session['temp_user'] = {
                "first_name": first_name,
                "last_name": last_name,
                "email": valid_email,
                "password": bcrypt.generate_password_hash(password).decode('utf-8'),
                "phone": phone,
                "profile_picture": profile_picture_filename
            }

            print(f"Generated OTP: {otp}")

            # Send OTP email
            msg = Message("Your OTP Code", sender=app.config['MAIL_USERNAME'], recipients=[valid_email])
            msg.body = f"Your OTP code is {otp}. Use this code to verify your email."
            mail.send(msg)

            flash("✅ OTP sent successfully. Please check your email.", "success")
            return redirect(url_for('verify_otp'))
        except Exception as e:
            flash(f"Error: {str(e)}", "danger")
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        user_otp = request.form['otp']

        # Convert stored OTP to string for comparison
        stored_otp = session.get('otp')
        if stored_otp is not None and str(stored_otp) == str(user_otp):  
            temp_user = session.get('temp_user')

            if temp_user:
                new_user = User(
                    first_name=temp_user['first_name'],
                    last_name=temp_user['last_name'],
                    email=temp_user['email'],
                    password=temp_user['password'],
                    phone=temp_user['phone'],
                    profile_picture=temp_user['profile_picture'],
                    is_verified=True
                )
                try:
                    db.session.add(new_user)
                    db.session.commit()
                    
                    # Clear session data after successful registration
                    session.pop('otp', None)
                    session.pop('temp_user', None)

                    flash("OTP Verified! You can now log in.", "success")
                    return redirect(url_for('login'))
                except Exception as e:
                    db.session.rollback()  # Rollback in case of error
                    flash(f"Database error: {str(e)}", "danger")
                    return redirect(url_for('register'))
            else:
                flash("Something went wrong. Please register again.", "danger")
                return redirect(url_for('register'))
        else:
            flash("Invalid OTP. Please try again.", "danger")

    return render_template('verify_otp.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    print("🟢 Login route accessed")  # Debugging
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        print(f"🔍 Attempting login for: {email}")  # Debugging
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            if not user.is_verified:
                flash("Please verify your email before logging in.", "warning")
                return redirect(url_for('login'))
            session['email'] = user.email
            print("✅ Login successful!")  # Debugging
            return redirect(url_for('dashboard'))
        else:
            print("❌ Invalid login attempt")  # Debugging
            flash("Invalid email or password.", "danger")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    print("🟢 Dashboard route accessed")  # Debugging

    if 'email' not in session:
        print("❌ No email in session, redirecting to login")  # Debugging
        flash("You must log in first!", "warning")
        return redirect(url_for('login'))
    
    print("✅ User is logged in, rendering dashboard")  # Debugging
    
    data = {
        "total_students": 1,
        "new_students": 0,
        "test_type": 4,
        "total_attempts": 84,
        "passed_attempts": 47,
        "failed_attempts": 37,
        "chart_data": [10, 20, 30, 40, 50, 60]
    }
    
    return render_template('dashboard.html', data=data)


@app.route('/users')
def user_list():
    users = User.query.all()
    return render_template('user_list.html', users=users)


@app.route('/users/delete/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    
    try:
        db.session.delete(user)
        db.session.commit()
        flash("User deleted successfully", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting user: {str(e)}", "danger")
    
    return redirect(url_for('user_list'))

@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    if request.method == 'POST':
        print("✅ Form Submitted!")

        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        phone = request.form.get('phone', '').strip()

        print(f"📌 Received Data: {first_name}, {last_name}, {email}, {phone}")

        if not first_name or not last_name or not email or not password or not phone:
            flash("⚠️ All fields are required!", "danger")
            print("❌ Validation Failed: Missing Fields")
            return redirect(url_for('add_user'))

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("⚠️ Email already registered!", "danger")
            print("❌ Validation Failed: Email Exists")
            return redirect(url_for('add_user'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hashed_password,
            phone=phone
        )

        try:
            db.session.add(new_user)
            db.session.commit()
            print("✅ User added successfully, redirecting...")
            flash("🎉 User added successfully!", "success")
            return redirect(url_for('user_list'))
        except IntegrityError:
            db.session.rollback()
            flash("⚠️ Email already exists!", "danger")
            return redirect(url_for('add_user'))
        except Exception as e:
            db.session.rollback()
            print(f"❌ Database Error: {e}")
            flash("⚠️ An unexpected error occurred.", "danger")
            return redirect(url_for('add_user'))

    print("🛠️ Rendering Add User Page")
    return render_template('add_user.html')

# Sample Test Type Data
test_types = [
    {"id": 1, "name": "Class-4 - French", "language": "", "created_on": "2024-08-07 22:02:38"},
    {"id": 2, "name": "Class-4 - French", "language": "", "created_on": "2024-08-07 22:16:43"},
    {"id": 3, "name": "7 - eng", "language": "", "created_on": "2024-10-03 17:43:11"},
    {"id": 4, "name": "class-8 - english", "language": "", "created_on": "2024-10-03 20:34:52"},
]

@app.route('/test-type', methods=['GET', 'POST'])
def test_type():
    search_query = request.args.get('search', '').strip().lower()

    # Filter test types based on search
    filtered_test_types = [
        t for t in test_types if search_query in t["name"].lower()
    ] if search_query else test_types

    return render_template('test_type.html', test_types=filtered_test_types, search_query=search_query)

@app.route('/add_test_type', methods=['GET', 'POST'])
def add_test_type():
    if request.method == 'POST':
        new_name = request.form.get('test-type', '').strip()
        new_language = request.form.get('language', '').strip()
        
        if new_name:
            new_id = max((t["id"] for t in test_types), default=0) + 1
            test_types.append({
                "id": new_id,
                "name": new_name,
                "language": new_language,
                "created_on": "2025-03-21 14:00:00"
            })
        return redirect(url_for('test_type'))  # Redirect to the test type listing page

    return render_template('add_test_type.html')

@app.route('/delete-test-type/<int:test_id>', methods=['POST'])
def delete_test_type(test_id):
    global test_types
    test_types = [t for t in test_types if t["id"] != test_id]
    return redirect(url_for('test_type'))


# Dummy test master data
test_masters = [
    {"id": 1, "test_type": "Math", "question": "What is 2 + 2?", "image": "None",
     "answer_a": "3", "answer_b": "4", "answer_c": "5", "answer_d": "6",
     "correct_answer": "4", "created_on": "2025-03-21", "created_by": "Admin"},
    
    {"id": 2, "test_type": "Science", "question": "What is H2O?", "image": "None",
     "answer_a": "Water", "answer_b": "Oxygen", "answer_c": "Hydrogen", "answer_d": "Carbon",
     "correct_answer": "Water", "created_on": "2025-03-21", "created_by": "Admin"}
]

@app.route('/test-master')
def test_master():
    return render_template('test_master.html', test_masters=test_masters)

@app.route('/add-test-master', methods=['GET', 'POST'])
def add_test_master():
    if request.method == 'POST':
        test_type = request.form.get('testType')
        question = request.form.get('question')
        question_image = request.files.get('questionImage')
        answer_a = request.form.get('answerA')
        answer_b = request.form.get('answerB')
        answer_c = request.form.get('answerC')
        answer_d = request.form.get('answerD')
        correct_answer = request.form.get('correctAnswer')

        # Save uploaded file (if any)
        image_filename = None
        if question_image and question_image.filename:
            image_filename = f"static/uploads/{question_image.filename}"
            question_image.save(image_filename)

        # Append new test data
        new_test = {
            "id": len(test_masters) + 1,
            "test_type": test_type,
            "question": question,
            "image": image_filename if image_filename else "None",
            "answer_a": answer_a,
            "answer_b": answer_b,
            "answer_c": answer_c,
            "answer_d": answer_d,
            "correct_answer": correct_answer,
            "created_on": "2025-03-21",
            "created_by": "Admin"
        }
        test_masters.append(new_test)

        print(f"Redirecting to: {url_for('test_master')}")  # Debugging print

        # Redirect to the test master page
        return redirect(url_for('test_master'))

    return render_template('add_test_master.html')


@app.route('/logout')
def logout():
    session.clear()  # Clear all session data
    return redirect(url_for('login'))  # Redirect to the login page

if __name__ == '__main__':
    app.run(debug=True)

    
from routes import *